/* global React, Ico, Logo, Field */
const { useState: useStateLand } = React;

function Landing({ navigate }) {
  return (
    <div className="landing">
      <Field />
      <header className="land-nav" style={{ borderColor: "rgb(84, 6, 240)", height: "8.7955px" }}>
        <Logo />
        <nav className="land-nav-links">
          <a href="#features">Features</a>
          <a href="#pricing">Pricing</a>
          <a href="#faq">FAQ</a>
        </nav>
        <div className="land-nav-cta">
          <button className="btn btn-ghost btn-sm" onClick={() => navigate("login")}>Sign in</button>
          <button className="btn btn-primary btn-sm" onClick={() => navigate("signup")}>Start free</button>
        </div>
      </header>

      {/* HERO */}
      <section className="hero">
        <div className="hero-pill">
          <span className="dot"></span>
          <span>AI job-search engine · Now in public beta</span>
        </div>

        <h1 className="hero-title" style={{ textAlign: "center", width: "1104.01px", height: "276.435px" }}>
          Stop guessing why<br />
          you're not <em style={{ fontFamily: "\"Instrument Serif\"" }}> getting </em><br />
          <em style={{ opacity: "9", fontFamily: "\"Instrument Serif\"", backgroundPosition: "center center", backgroundSize: "cover", borderColor: "rgb(74, 127, 221)" }}>                          interviews! </em>
        </h1>

        <p className="hero-sub">
          Reckon reads any job posting, scores it against your resume, surfaces the
          exact gaps, and writes the outreach email — in under thirty seconds.
        </p>

        <div className="hero-cta">
          <button className="btn btn-primary btn-lg" onClick={() => navigate("signup")}>
            Start free — 3 jobs on us
            <Ico.arrow style={{ width: 16, height: 16 }} />
          </button>
          <button className="btn btn-ghost btn-lg" onClick={() => navigate("login")}>
            Watch a 60-second demo
          </button>
        </div>

        {/* Visual: floating score ring + cards */}
        <div className="hero-vis">
          <div className="vis-card vis-score">
            <div className="vis-card-head">
              <span className="kicker">Match</span>
              <span className="pill pill-good"><span className="dot"></span>Strong fit</span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
              <ScoreRing value={87} size={120} stroke={9} />
              <div style={{ flex: 1, fontSize: 13, color: "var(--text-2)", lineHeight: 1.6 }}>
                Skills <span style={{ color: "var(--text)" }}>9/10</span><br />
                Experience <span style={{ color: "var(--text)" }}>4 yrs</span><br />
                ATS keywords <span style={{ color: "var(--good)" }}>passing</span>
              </div>
            </div>
          </div>
          <div className="vis-card vis-mail">
            <div className="kicker" style={{ marginBottom: 10 }}>Generated outreach</div>
            <div style={{ fontFamily: "var(--serif)", fontStyle: "italic", fontSize: 18, lineHeight: 1.4, color: "var(--text)" }}>
              "Hi Mira — your team's recent work on usability metrics is exactly the
              kind of mixed-methods research I've spent the last four years on…"
            </div>
            <div className="vis-typing"><span></span><span></span><span></span></div>
          </div>
          <div className="vis-card vis-gaps">
            <div className="kicker" style={{ marginBottom: 10 }}>Gaps to close</div>
            <div className="vis-tags">
              <span className="vis-tag bad">SQL</span>
              <span className="vis-tag warn">5 yrs exp</span>
              <span className="vis-tag warn">Quant methods</span>
            </div>
          </div>
          <div className="vis-glow"></div>
        </div>

        {/* Stats row */}
        <div className="stats-row">
          <div className="stat-cell">
            <div className="stat-num">78<span>%</span></div>
            <div className="stat-lbl">avg. match-score lift after first edit pass</div>
          </div>
          <div className="stat-cell">
            <div className="stat-num">4.2<span>×</span></div>
            <div className="stat-lbl">more interview replies vs. self-reported baseline</div>
          </div>
          <div className="stat-cell">
            <div className="stat-num">28<span>s</span></div>
            <div className="stat-lbl">median time to analyse a fresh posting</div>
          </div>
          <div className="stat-cell">
            <div className="stat-num">2,400<span>+</span></div>
            <div className="stat-lbl">job-seekers using Reckon as of this week</div>
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section className="features" id="features">
        <div className="section-head">
          <span className="kicker">What it does</span>
          <h2 className="h-display" style={{ fontSize: 48 }}>
            Six things between you<br /> and your <em>next offer.</em>
          </h2>
        </div>
        <div className="feat-grid">
          {features.map((f, i) =>
          <div className="feat-card" key={i}>
              <div className="feat-num">{String(i + 1).padStart(2, "0")}</div>
              <div className="feat-ico">{f.icon}</div>
              <h3 className="feat-title">{f.title}</h3>
              <p className="feat-desc">{f.desc}</p>
            </div>
          )}
        </div>
      </section>

      {/* PRICING */}
      <section className="pricing" id="pricing">
        <div className="section-head">
          <span className="kicker">Pricing</span>
          <h2 className="h-display" style={{ fontSize: 48 }}>
            Honest pricing.<br />
            <em>No annual lock-in.</em>
          </h2>
        </div>

        <div className="price-grid">
          <div className="price-card">
            <div className="price-tag">Pay-as-you-go</div>
            <div className="price-amt">
              <span className="curr" style={{ margin: "3px 0px 0px" }}>$</span>1
              <span className="per" style={{ margin: "36px 0px 0px 8px", letterSpacing: "-1px" }}>per 12 jobs</span>
            </div>
            <p className="price-desc">For focused, short job hunts. Pay only when you actually use it.</p>
            <ul className="price-feat">
              <li><Ico.check style={{ width: 14, height: 14 }} /> 3 free analyses to start</li>
              <li><Ico.check style={{ width: 14, height: 14 }} /> Full Match Score + email</li>
              <li><Ico.check style={{ width: 14, height: 14 }} /> Kanban tracker, exports</li>
              <li><Ico.check style={{ width: 14, height: 14 }} /> No expiry on credits</li>
            </ul>
            <button className="btn btn-soft btn-block btn-lg" onClick={() => navigate("signup")} style={{ opacity: "1", justifyContent: "center", letterSpacing: "-0.075px" }}>Start with credits</button>
          </div>

          <div className="price-card price-card-feat">
            <div className="price-ribbon" style={{ borderRadius: "300px", height: "24.8011px", width: "155.412px", lineHeight: "1.5", textAlign: "center" }}>most popular</div>
            <div className="price-tag">Monthly</div>
            <div className="price-amt">
              <span className="curr" style={{ textAlign: "left", opacity: "1", padding: "0px", lineHeight: "1", margin: "3px 0px 0px" }}>$</span>19
              <span className="per" style={{ letterSpacing: "-1px" }}>per month</span>
            </div>
            <p className="price-desc">Unlimited everything for active hunts. 7-day trial, cancel in one click.</p>
            <ul className="price-feat">
              <li><Ico.check style={{ width: 14, height: 14 }} /> Unlimited analyses & emails</li>
              <li><Ico.check style={{ width: 14, height: 14 }} /> Follow-up reminders</li>
              <li><Ico.check style={{ width: 14, height: 14 }} /> Priority AI processing</li>
              <li><Ico.check style={{ width: 14, height: 14 }} /> Market-position reports</li>
              <li><Ico.check style={{ width: 14, height: 14 }} /> 7-day free trial</li>
            </ul>
            <button className="btn btn-primary btn-block btn-lg" onClick={() => navigate("signup")}>Start 7-day trial</button>
          </div>
        </div>

        <p className="price-foot">
          Billed via Lemon Squeezy. Cancel anytime — your data stays read-only for 60 days.
        </p>
      </section>

      <footer className="land-foot">
        <Logo />
        <div className="foot-cols">
          <a>Privacy</a><a>Terms</a><a>Contact</a><a>Changelog</a>
        </div>
        <div className="foot-meta">© 2026 purple Reckon · Made for people who hate job hunting.</div>
      </footer>

      <style>{landingStyles}</style>
    </div>);

}

const features = [
{ title: "Paste any job URL", desc: "LinkedIn, Indeed, Greenhouse, Workday, or a company careers page. Reckon extracts everything in seconds.",
  icon: <Ico.link style={{ width: 22, height: 22 }} /> },
{ title: "Vision-AI for screenshots", desc: "Posting behind a login wall? Drop a screenshot. The AI reads the image and fills in every field.",
  icon: <Ico.image style={{ width: 22, height: 22 }} /> },
{ title: "Real match scoring", desc: "Not a vibe — a 0–100 score broken down by skills, experience, and ATS keyword coverage. With reasoning.",
  icon: <Ico.spark style={{ width: 22, height: 22 }} /> },
{ title: "Gap-targeted rewrite tips", desc: "We tell you which exact bullet to add to your resume to close the most-blocking gaps for this specific role.",
  icon: <Ico.pencil style={{ width: 22, height: 22 }} /> },
{ title: "Outreach email, written for you", desc: "A tailored opener referencing the company and the role — not a template, not generic, ready to send.",
  icon: <Ico.copy style={{ width: 22, height: 22 }} /> },
{ title: "A pipeline that nudges you", desc: "Kanban for every stage. Quiet for 7 days? You'll get a follow-up draft in your inbox before you forget.",
  icon: <Ico.bell style={{ width: 22, height: 22 }} /> }];


const landingStyles = `
.landing { min-height: 100vh; }
.land-nav {
  display: flex; align-items: center; justify-content: space-between;
  padding: 22px 48px;
  position: sticky; top: 0; z-index: 30;
  background: rgba(10,6,18,0.6); backdrop-filter: blur(14px);
  border-bottom: 1px solid var(--line);
}
.land-nav-links { display: flex; gap: 28px; font-size: 13px; color: var(--text-2); }
.land-nav-links a { transition: color .15s; }
.land-nav-links a:hover { color: var(--text); }
.land-nav-cta { display: flex; gap: 8px; }

.hero {
  max-width: 1200px;
  margin: 0 auto;
  padding: 80px 48px 100px;
  text-align: center;
  position: relative;
}
.hero-pill {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 6px 14px;
  border-radius: 100px;
  border: 1px solid var(--line-strong);
  background: rgba(168,85,247,0.06);
  font-family: var(--mono); font-size: 11px; letter-spacing: 0.08em;
  color: var(--text-2); text-transform: uppercase;
  margin-bottom: 32px;
}
.hero-pill .dot { width: 6px; height: 6px; border-radius: 50%; background: var(--violet-bright); box-shadow: 0 0 10px var(--violet-bright); animation: pulse 2.4s ease-in-out infinite; }
@keyframes pulse { 0%,100% { opacity: 1 } 50% { opacity: 0.4 } }

.hero-title {
  font-family: var(--serif);
  font-weight: 400;
  font-size: clamp(48px, 8vw, 96px);
  line-height: 0.96;
  letter-spacing: -0.035em;
  color: var(--text);
  margin-bottom: 28px;
}
.hero-title em {
  font-style: italic;
  color: transparent;
  background: linear-gradient(140deg, #d8b4fe 10%, #a855f7 50%, #7c3aed 95%);
  -webkit-background-clip: text;
  background-clip: text;
}

.hero-sub {
  max-width: 600px;
  margin: 0 auto 40px;
  font-size: 18px;
  color: var(--text-2);
  line-height: 1.55;
}
.hero-cta { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; margin-bottom: 96px; }

/* Hero visualization */
.hero-vis {
  position: relative;
  max-width: 980px;
  margin: 0 auto 96px;
  height: 360px;
}
.hero-vis::before {
  content: "";
  position: absolute; inset: -40px;
  background: radial-gradient(ellipse at center, rgba(168,85,247,0.18), transparent 60%);
  pointer-events: none;
}
.vis-card {
  position: absolute;
  background: linear-gradient(180deg, rgba(29, 19, 48, 0.85) 0%, rgba(15,10,26,0.85) 100%);
  backdrop-filter: blur(12px);
  border: 1px solid var(--line-strong);
  border-radius: 18px;
  padding: 22px;
  text-align: left;
  box-shadow: 0 24px 60px -16px rgba(0,0,0,0.5);
}
.vis-score { width: 360px; left: 50%; top: 30px; transform: translateX(-50%); z-index: 3; }
.vis-card-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px; }
.vis-mail { width: 320px; left: 0; top: 100px; transform: rotate(-3deg); z-index: 2; }
.vis-typing { display: flex; gap: 4px; margin-top: 14px; }
.vis-typing span {
  width: 6px; height: 6px; border-radius: 50%; background: var(--violet-bright);
  animation: type-bounce 1.4s ease-in-out infinite;
}
.vis-typing span:nth-child(2) { animation-delay: 0.2s; }
.vis-typing span:nth-child(3) { animation-delay: 0.4s; }
@keyframes type-bounce { 0%,60%,100% { opacity: 0.3; transform: translateY(0); } 30% { opacity: 1; transform: translateY(-3px); } }
.vis-gaps { width: 240px; right: 0; top: 130px; transform: rotate(3deg); z-index: 2; }
.vis-tags { display: flex; flex-wrap: wrap; gap: 6px; }
.vis-tag {
  font-family: var(--mono); font-size: 11px; padding: 4px 10px; border-radius: 100px;
  border: 1px solid; background: transparent;
}
.vis-tag.bad { color: var(--bad); border-color: rgba(251,113,133,0.3); }
.vis-tag.warn { color: var(--warn); border-color: rgba(251,191,36,0.3); }

.stats-row {
  display: grid; grid-template-columns: repeat(4, 1fr);
  gap: 24px;
  padding-top: 56px;
  border-top: 1px solid var(--line);
  text-align: left;
}
.stat-cell {}
.stat-num {
  font-family: var(--serif);
  font-size: 60px;
  font-weight: 400;
  line-height: 1;
  letter-spacing: -0.04em;
  color: var(--text);
  margin-bottom: 10px;
}
.stat-num span { font-style: italic; color: var(--violet-bright); font-size: 0.6em; margin-left: 2px; }
.stat-lbl { font-size: 13px; color: var(--text-3); line-height: 1.4; max-width: 200px; }

/* Features */
.features {
  max-width: 1200px;
  margin: 0 auto;
  padding: 80px 48px;
}
.section-head { text-align: left; margin-bottom: 48px; }
.section-head .kicker { display: block; margin-bottom: 16px; }

.feat-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1px;
  background: var(--line);
  border: 1px solid var(--line);
  border-radius: 22px;
  overflow: hidden;
}
.feat-card {
  background: var(--bg);
  padding: 32px 28px;
  position: relative;
  min-height: 240px;
  transition: background .2s;
}
.feat-card:hover { background: var(--surface); }
.feat-num {
  font-family: var(--mono);
  font-size: 11px;
  color: var(--text-4);
  letter-spacing: 0.1em;
  position: absolute;
  top: 24px; right: 24px;
}
.feat-ico {
  width: 44px; height: 44px;
  border-radius: 11px;
  background: linear-gradient(135deg, rgba(168,85,247,0.15), rgba(124,58,237,0.05));
  border: 1px solid var(--line-strong);
  display: grid; place-items: center;
  color: var(--violet-bright);
  margin-bottom: 24px;
}
.feat-title {
  font-family: var(--serif);
  font-weight: 400;
  font-size: 22px;
  line-height: 1.15;
  color: var(--text);
  margin-bottom: 10px;
  letter-spacing: -0.01em;
}
.feat-desc { font-size: 13.5px; color: var(--text-2); line-height: 1.55; }

/* Pricing */
.pricing { max-width: 1100px; margin: 0 auto; padding: 80px 48px; }
.price-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  margin-bottom: 28px;
}
.price-card {
  position: relative;
  border: 1px solid var(--line);
  border-radius: 22px;
  padding: 36px;
  background: var(--surface);
}
.price-card-feat {
  background: linear-gradient(160deg, rgba(168,85,247,0.12), var(--surface) 60%);
  border-color: var(--line-strong);
  box-shadow: 0 24px 60px -20px rgba(168,85,247,0.3);
}
.price-ribbon {
  position: absolute; top: 20px; right: 20px;
  font-family: var(--mono); font-size: 10px;
  letter-spacing: 0.18em; text-transform: uppercase;
  color: var(--violet-bright);
  background: rgba(168,85,247,0.12);
  border: 1px solid var(--line-strong);
  padding: 4px 10px;
  border-radius: 100px;
}
.price-tag { font-size: 13px; color: var(--text-2); margin-bottom: 16px; }
.price-amt {
  font-family: var(--serif);
  font-size: 86px;
  font-weight: 400;
  line-height: 1;
  letter-spacing: -0.04em;
  color: var(--text);
  margin-bottom: 16px;
  display: flex; align-items: flex-start; gap: 4px;
}
.price-amt .curr { font-size: 32px; color: var(--violet-bright); margin-top: 12px; font-style: italic; }
.price-amt .per { font-family: var(--sans); font-size: 14px; color: var(--text-3); font-weight: 400; margin-top: 36px; margin-left: 8px; }
.price-desc { font-size: 14px; color: var(--text-2); line-height: 1.5; margin-bottom: 24px; min-height: 42px; }
.price-feat { list-style: none; display: flex; flex-direction: column; gap: 10px; margin-bottom: 28px; }
.price-feat li { display: flex; align-items: center; gap: 10px; font-size: 13.5px; color: var(--text-2); }
.price-feat li svg { color: var(--violet-bright); flex-shrink: 0; }
.price-foot { text-align: center; font-size: 13px; color: var(--text-3); }

/* Footer */
.land-foot {
  max-width: 1200px; margin: 60px auto 0;
  padding: 40px 48px;
  border-top: 1px solid var(--line);
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  align-items: center;
  gap: 24px;
}
.foot-cols { display: flex; gap: 24px; justify-content: center; font-size: 13px; color: var(--text-3); }
.foot-cols a { cursor: pointer; transition: color .15s; }
.foot-cols a:hover { color: var(--text); }
.foot-meta { font-size: 12px; color: var(--text-4); text-align: right; font-family: var(--mono); }

@media (max-width: 880px) {
  .land-nav { padding: 16px 20px; }
  .land-nav-links { display: none; }
  .hero { padding: 48px 20px 60px; }
  .hero-vis { display: none; }
  .stats-row { grid-template-columns: 1fr 1fr; gap: 32px; }
  .stat-num { font-size: 44px; }
  .features, .pricing { padding: 56px 20px; }
  .feat-grid { grid-template-columns: 1fr; }
  .price-grid { grid-template-columns: 1fr; }
  .price-amt { font-size: 64px; }
  .land-foot { grid-template-columns: 1fr; text-align: center; padding: 32px 20px; }
  .foot-meta { text-align: center; }
}
`;

window.Landing = Landing;