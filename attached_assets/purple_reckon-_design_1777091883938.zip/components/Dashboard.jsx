/* global React, Ico, Logo, ScoreRing */

const SAMPLE_JOBS = [
// Saved
{ id: 1, col: "saved", company: "Stripe", title: "Senior Product Designer", score: 64, when: "Today", logo: "S" },
{ id: 2, col: "saved", company: "Notion", title: "Frontend Engineer", score: 82, when: "Yesterday", logo: "N" },
{ id: 3, col: "saved", company: "Anthropic", title: "Design Engineer, Claude UI", score: 76, when: "2 days ago", logo: "A" },
// Applied
{ id: 4, col: "applied", company: "Google", title: "Senior UX Researcher", score: 72, when: "3 days ago", followUp: true, logo: "G" },
{ id: 5, col: "applied", company: "Airbnb", title: "Product Manager, Trips", score: 58, when: "5 days ago", logo: "A" },
{ id: 6, col: "applied", company: "Ramp", title: "Founding Designer", score: 79, when: "1 week ago", followUp: true, logo: "R" },
// Interview
{ id: 7, col: "interview", company: "Figma", title: "Growth Lead", score: 88, when: "Round 2 · Thu", logo: "F" },
{ id: 8, col: "interview", company: "Linear", title: "Head of Design", score: 91, when: "Final round", logo: "L" },
// Rejected
{ id: 9, col: "rejected", company: "Meta", title: "Product Designer", score: 41, when: "2 weeks ago", logo: "M" },
// Offer
{ id: 10, col: "offer", company: "Vercel", title: "Senior Designer", score: 94, when: "Decision pending", logo: "V" }];


const COLS = [
{ key: "saved", label: "Saved", hint: "Considering" },
{ key: "applied", label: "Applied", hint: "Awaiting reply" },
{ key: "interview", label: "Interview", hint: "In conversation" },
{ key: "rejected", label: "Rejected", hint: "Closed loops" },
{ key: "offer", label: "Offer", hint: "On the table", accent: true }];


function Sidebar({ active, navigate, user, onSignOut, mobileOpen, onCloseMobile }) {
  const items = [
  { key: "dashboard", label: "Dashboard", icon: <Ico.dashboard style={{ width: 16, height: 16 }} /> },
  { key: "all-jobs", label: "All Jobs", icon: <Ico.briefcase style={{ width: 16, height: 16 }} /> },
  { key: "resume", label: "My Resume", icon: <Ico.resume style={{ width: 16, height: 16 }} /> },
  { key: "reminders", label: "Reminders", icon: <Ico.bell style={{ width: 16, height: 16 }} />, count: 2 },
  { key: "analytics", label: "Analytics", icon: <Ico.chart style={{ width: 16, height: 16 }} /> }];

  return (
    <>
      {mobileOpen && <div className="sidebar-backdrop" onClick={onCloseMobile}></div>}
      <aside className={`sidebar ${mobileOpen ? "open" : ""}`}>
        <div className="sidebar-head" style={{ textAlign: "justify" }}><Logo /></div>
        <nav className="nav-list">
          {items.map((it) =>
          <a key={it.key} className={`nav-item ${active === it.key ? "active" : ""}`}
          onClick={() => {navigate(it.key === "dashboard" ? "dashboard" : it.key);onCloseMobile && onCloseMobile();}}>
              <span className="ico">{it.icon}</span>
              <span style={{ flex: 1 }}>{it.label}</span>
              {it.count && <span className="pill pill-violet" style={{ height: 18, padding: "0 8px", fontSize: 10 }}>{it.count}</span>}
            </a>
          )}
        </nav>
        <div className="nav-divider"></div>
        <nav className="nav-list">
          <a className={`nav-item ${active === "settings" ? "active" : ""}`} onClick={() => {navigate("settings");onCloseMobile && onCloseMobile();}}>
            <span className="ico"><Ico.settings style={{ width: 16, height: 16 }} /></span>Settings
          </a>
          <a className="nav-item" onClick={() => {onSignOut();onCloseMobile && onCloseMobile();}}>
            <span className="ico"><Ico.signout style={{ width: 16, height: 16 }} /></span>Sign out
          </a>
        </nav>

        <div className="sidebar-foot">
          <div className="user-chip">
            <div className="avatar">{(user?.name || "I A").split(" ").map((s) => s[0]).slice(0, 2).join("")}</div>
            <div className="who">
              <div className="name">{user?.name || "Ido Azulay"}</div>
              <div className="email">{user?.email || "ido@example.com"}</div>
            </div>
          </div>
        </div>
      </aside>
    </>);

}

function StatCard({ label, value, sub, tone = "default", trend }) {
  return (
    <div className="stat-card">
      <div className="stat-card-top">
        <span className="kicker">{label}</span>
        {trend && <span className={`stat-trend ${trend.dir}`}>{trend.dir === "up" ? "↑" : "↓"} {trend.value}</span>}
      </div>
      <div className={`stat-value tone-${tone}`}>{value}</div>
      <div className="stat-sub">{sub}</div>
    </div>);

}

function JobCard({ job, onClick }) {
  const tone = job.score >= 80 ? "good" : job.score >= 60 ? "violet" : job.score >= 40 ? "warn" : "bad";
  return (
    <div className="job-card" onClick={onClick}>
      <div className="job-card-top">
        <div className="job-logo">{job.logo}</div>
        <span className={`pill pill-${tone}`}>{job.score}</span>
      </div>
      <div className="job-company">{job.company}</div>
      <div className="job-title">{job.title}</div>
      <div className="job-card-foot">
        <span className="job-when">{job.when}</span>
        {job.followUp && <span className="follow-badge"><span className="pulse-dot"></span>Follow up</span>}
      </div>
    </div>);

}

function Dashboard({ user, navigate, onAddJob, onSignOut, openMobile, mobileOpen, onCloseMobile }) {
  const [jobs] = React.useState(SAMPLE_JOBS);
  const [filter, setFilter] = React.useState("");
  const filtered = React.useMemo(() =>
  jobs.filter((j) => !filter || j.title.toLowerCase().includes(filter.toLowerCase()) || j.company.toLowerCase().includes(filter.toLowerCase())),
  [jobs, filter]);

  const greet = (() => {
    const h = new Date().getHours();
    return h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
  })();

  return (
    <div className="app">
      <Sidebar active="dashboard" navigate={navigate} user={user} onSignOut={onSignOut} mobileOpen={mobileOpen} onCloseMobile={onCloseMobile} />
      <main className="main">
        <div className="mobile-bar">
          <Logo />
          <button className="menu-btn" onClick={openMobile}><Ico.menu style={{ width: 18, height: 18 }} /></button>
        </div>

        <div className="main-header">
          <div>
            <div className="greet">{greet}, {(user?.name || "Ido").split(" ")[0]}.</div>
            <h1>Your <em style={{ fontFamily: "Oswald", color: "rgb(143, 43, 243)" }}>pipeline</em>.</h1>
          </div>
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <div className="search-wrap">
              <Ico.search style={{ width: 14, height: 14 }} />
              <input className="search-in" placeholder="Search jobs…" value={filter} onChange={(e) => setFilter(e.target.value)} />
            </div>
            <button className="btn btn-primary" onClick={onAddJob}>
              <Ico.plus style={{ width: 16, height: 16 }} /> Add job
            </button>
          </div>
        </div>

        <div className="stats-grid">
          <StatCard label="Total Applied" value="24" sub="across 5 stages" tone="default" trend={{ dir: "up", value: "+6 wk" }} />
          <StatCard label="Interviews" value="4" sub="2 in final round" tone="good" trend={{ dir: "up", value: "+2" }} />
          <StatCard label="Avg Match" value="71%" sub="last 10 analyses" tone="violet" />
          <StatCard label="Offers" value="1" sub="awaiting decision" tone="violet" />
        </div>

        <div className="kanban-head">
          <h2 className="h-display" style={{ fontSize: 22 }}>Applications pipeline</h2>
          <div style={{ display: "flex", gap: 16, alignItems: "center", fontSize: 12, color: "var(--text-3)" }}>
            <span><span className="pulse-dot" style={{ background: "var(--violet-bright)" }}></span> 2 follow-ups due</span>
            <span style={{ fontFamily: "var(--mono)" }}>{filtered.length} cards</span>
          </div>
        </div>

        <div className="kanban">
          {COLS.map((col) => {
            const colJobs = filtered.filter((j) => j.col === col.key);
            return (
              <div className={`kanban-col ${col.accent ? "accent" : ""}`} key={col.key} style={{ borderWidth: "0.81818px 0.909091px 0.909091px", borderStyle: "solid" }}>
                <div className="kanban-col-head">
                  <div>
                    <div className="kanban-col-title">{col.label}</div>
                    <div className="kanban-col-hint">{col.hint}</div>
                  </div>
                  <span className="kanban-count">{colJobs.length}</span>
                </div>
                <div className="kanban-col-list">
                  {colJobs.map((j) => <JobCard key={j.id} job={j} onClick={() => navigate("job-detail", { jobId: j.id })} />)}
                  {colJobs.length === 0 && <div className="kanban-empty">No jobs here.</div>}
                </div>
              </div>);

          })}
        </div>

        <style>{dashStyles}</style>
      </main>
    </div>);

}

const dashStyles = `
.search-wrap {
  display: flex; align-items: center; gap: 8px;
  background: var(--surface);
  border: 1px solid var(--line);
  border-radius: 10px;
  padding: 0 12px;
  height: 40px;
  width: 240px;
  color: var(--text-3);
  transition: border-color .15s;
}
.search-wrap:focus-within { border-color: var(--violet); color: var(--text); }
.search-in {
  flex: 1; background: none; border: none; outline: none;
  color: var(--text); font-size: 13px;
}
.search-in::placeholder { color: var(--text-4); }

.stats-grid {
  display: grid; grid-template-columns: repeat(4, 1fr);
  gap: 14px;
  margin-bottom: 36px;
}
.stat-card {
  padding: 22px;
  border-radius: 16px;
  background: linear-gradient(180deg, var(--surface) 0%, var(--bg-2) 100%);
  border: 1px solid var(--line);
  position: relative; overflow: hidden;
}
.stat-card::before {
  content: ""; position: absolute; top: 0; right: 0; width: 80px; height: 80px;
  background: radial-gradient(circle, rgba(168,85,247,0.18), transparent 70%);
  pointer-events: none;
}
.stat-card-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 18px; }
.stat-trend { font-family: var(--mono); font-size: 11px; padding: 2px 8px; border-radius: 100px; }
.stat-trend.up { color: var(--good); background: rgba(110,231,183,0.08); }
.stat-trend.down { color: var(--bad); background: rgba(251,113,133,0.08); }
.stat-value {
  font-family: var(--serif); font-weight: 400;
  font-size: 56px; line-height: 1; letter-spacing: -0.03em;
  margin-bottom: 8px;
}
.stat-value.tone-good { color: var(--good); }
.stat-value.tone-violet { color: var(--violet-bright); }
.stat-sub { font-size: 12px; color: var(--text-3); }

.kanban-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.pulse-dot { display: inline-block; width: 6px; height: 6px; border-radius: 50%; background: var(--violet-bright); margin-right: 6px; box-shadow: 0 0 8px var(--violet-bright); animation: pulse 1.8s infinite; }

.kanban {
  display: grid; grid-template-columns: repeat(5, minmax(220px, 1fr));
  gap: 14px;
}
.kanban-col {
  background: rgba(15, 10, 26, 0.5);
  border: 1px solid var(--line);
  border-radius: 14px;
  padding: 14px;
  min-height: 300px;
}
.kanban-col.accent {
  background: linear-gradient(180deg, rgba(168,85,247,0.08), rgba(15,10,26,0.5));
  border-color: var(--line-strong);
}
.kanban-col-head {
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 4px 12px;
  margin-bottom: 12px;
  border-bottom: 1px dashed var(--line);
}
.kanban-col-title {
  font-size: 12px; font-weight: 600; font-family: var(--mono);
  letter-spacing: 0.1em; text-transform: uppercase;
  color: var(--text);
}
.kanban-col-hint { font-size: 11px; color: var(--text-4); margin-top: 2px; }
.kanban-count {
  background: var(--surface-2);
  border: 1px solid var(--line);
  border-radius: 100px;
  padding: 2px 9px;
  font-size: 11px; font-family: var(--mono);
  color: var(--text-2);
}
.kanban-col-list { display: flex; flex-direction: column; gap: 10px; }
.kanban-empty {
  text-align: center; font-size: 12px; color: var(--text-4);
  padding: 24px 0; font-style: italic;
}

.job-card {
  background: var(--surface);
  border: 1px solid var(--line);
  border-radius: 12px;
  padding: 14px;
  cursor: pointer;
  transition: transform .15s, border-color .15s, background .15s;
  position: relative;
}
.job-card:hover {
  transform: translateY(-2px);
  border-color: var(--line-strong);
  background: var(--surface-2);
  box-shadow: 0 12px 28px -10px rgba(168,85,247,0.25);
}
.job-card-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
.job-logo {
  width: 28px; height: 28px;
  border-radius: 8px;
  background: linear-gradient(135deg, var(--surface-2), var(--surface-3));
  border: 1px solid var(--line);
  display: grid; place-items: center;
  font-family: var(--serif); font-style: italic; font-size: 14px; color: var(--violet-bright);
}
.job-company { font-family: var(--mono); font-size: 11px; color: var(--text-3); letter-spacing: 0.04em; margin-bottom: 4px; }
.job-title { font-family: var(--serif); font-size: 16px; line-height: 1.2; color: var(--text); margin-bottom: 14px; letter-spacing: -0.01em; }
.job-card-foot { display: flex; justify-content: space-between; align-items: center; }
.job-when { font-size: 11px; color: var(--text-4); font-family: var(--mono); }
.follow-badge {
  display: inline-flex; align-items: center;
  font-size: 10px; font-weight: 500;
  font-family: var(--mono); text-transform: uppercase; letter-spacing: 0.06em;
  color: var(--violet-bright);
}

@media (max-width: 1100px) {
  .kanban { grid-template-columns: repeat(3, 1fr); overflow-x: auto; }
}
@media (max-width: 880px) {
  .stats-grid { grid-template-columns: 1fr 1fr; }
  .stat-value { font-size: 40px; }
  .kanban { grid-template-columns: 1fr; }
  .search-wrap { display: none; }
}
`;

window.Dashboard = Dashboard;
window.SAMPLE_JOBS = SAMPLE_JOBS;
window.Sidebar = Sidebar;