/* global React, Ico, Logo, Field */

function Auth({ mode, navigate, onLogin }) {
  const isSignup = mode === "signup";
  const [name, setName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [pw, setPw] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [err, setErr] = React.useState("");

  const submit = (e) => {
    e.preventDefault();
    setErr("");
    if (!email || !pw || (isSignup && !name)) { setErr("Please fill all fields."); return; }
    if (!email.includes("@")) { setErr("Please enter a valid email."); return; }
    if (pw.length < 6) { setErr("Password must be at least 6 characters."); return; }
    setLoading(true);
    setTimeout(() => {
      onLogin({ name: name || "Ido Azulay", email, plan: "trial" });
      navigate("dashboard");
    }, 700);
  };

  const google = () => {
    setLoading(true);
    setTimeout(() => {
      onLogin({ name: "Ido Azulay", email: "ido@gmail.com", plan: "trial" });
      navigate("dashboard");
    }, 600);
  };

  return (
    <div className="auth-page">
      <Field />
      <div className="auth-nav">
        <div onClick={() => navigate("landing")} style={{ cursor: "pointer" }}><Logo /></div>
      </div>

      <div className="auth-grid">
        <div className="auth-side">
          <span className="kicker">{isSignup ? "Create account" : "Welcome back"}</span>
          <h1 className="h-display" style={{ fontSize: 64, marginTop: 16, marginBottom: 24 }}>
            {isSignup ? <>Find the offer<br/><em>hiding in your inbox.</em></> : <>Your jobs<br/><em>are waiting.</em></>}
          </h1>
          <p style={{ fontSize: 16, color: "var(--text-2)", lineHeight: 1.55, maxWidth: 420 }}>
            {isSignup
              ? "Three full analyses on the house. No card, no commitment — just paste a job and watch what Reckon sees."
              : "Pick up where you left off. Your pipeline, score history, and drafts are all where you left them."}
          </p>
          <div className="auth-trust">
            <div className="trust-item"><Ico.lock style={{ width: 14, height: 14 }}/> SSO via Supabase</div>
            <div className="trust-item"><Ico.check style={{ width: 14, height: 14 }}/> SOC2-ready infra</div>
            <div className="trust-item"><Ico.spark style={{ width: 14, height: 14 }}/> Cancel in one click</div>
          </div>
        </div>

        <form className="auth-card" onSubmit={submit}>
          <div className="auth-tabs">
            <button type="button" className={!isSignup ? "active" : ""} onClick={() => navigate("login")}>Sign in</button>
            <button type="button" className={isSignup ? "active" : ""} onClick={() => navigate("signup")}>Create account</button>
            <span className="auth-tab-pill" style={{ left: isSignup ? "50%" : "0%" }}></span>
          </div>

          {isSignup && (
            <div className="field">
              <label className="field-label">Full name</label>
              <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ido Azulay" />
            </div>
          )}
          <div className="field">
            <label className="field-label">Email address</label>
            <input className="input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="ido@example.com" autoComplete="email" />
          </div>
          <div className="field">
            <label className="field-label">Password</label>
            <input className="input" type="password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="••••••••" autoComplete={isSignup ? "new-password" : "current-password"} />
            {!isSignup && <a className="auth-forgot" onClick={(e) => { e.preventDefault(); }}>Forgot password?</a>}
          </div>

          {err && <div className="auth-err">{err}</div>}

          <button className="btn btn-primary btn-block btn-lg" type="submit" disabled={loading}>
            {loading ? <span className="spinner"></span> : (isSignup ? "Create free account" : "Sign in")}
            {!loading && <Ico.arrow style={{ width: 16, height: 16 }} />}
          </button>

          <div className="auth-divider"><span>or continue with</span></div>

          <button className="btn btn-soft btn-block btn-lg" type="button" onClick={google} disabled={loading}>
            <Ico.google style={{ width: 16, height: 16 }} /> Continue with Google
          </button>

          {isSignup && (
            <div className="auth-gift">
              <Ico.spark style={{ width: 14, height: 14, color: "var(--violet-bright)" }} />
              First 3 analyses are free. No card needed.
            </div>
          )}

          <div className="auth-foot">
            {isSignup
              ? <>Already have an account? <a onClick={() => navigate("login")}>Sign in</a></>
              : <>New to Reckon? <a onClick={() => navigate("signup")}>Start free</a></>
            }
          </div>
        </form>
      </div>

      <style>{authStyles}</style>
    </div>
  );
}

const authStyles = `
.auth-page { min-height: 100vh; }
.auth-nav { padding: 22px 48px; }
.auth-grid {
  max-width: 1200px;
  margin: 0 auto;
  padding: 40px 48px 80px;
  display: grid;
  grid-template-columns: 1fr 480px;
  gap: 80px;
  align-items: center;
}
.auth-side .h-display em { font-style: italic; }
.auth-trust { display: flex; flex-direction: column; gap: 12px; margin-top: 36px; }
.trust-item { display: flex; align-items: center; gap: 10px; font-size: 13px; color: var(--text-3); font-family: var(--mono); }
.trust-item svg { color: var(--violet-bright); }

.auth-card {
  background: linear-gradient(180deg, var(--surface) 0%, var(--bg-2) 100%);
  border: 1px solid var(--line-strong);
  border-radius: 22px;
  padding: 36px;
  display: flex; flex-direction: column; gap: 16px;
  box-shadow: 0 30px 80px -20px rgba(0,0,0,0.5);
}
.auth-tabs {
  position: relative;
  display: grid; grid-template-columns: 1fr 1fr;
  background: var(--surface-2);
  border-radius: 10px;
  padding: 4px;
  margin-bottom: 8px;
}
.auth-tabs button {
  position: relative; z-index: 2;
  padding: 9px;
  border-radius: 7px;
  font-size: 13px; font-weight: 500;
  color: var(--text-3);
  transition: color .2s;
}
.auth-tabs button.active { color: var(--text); }
.auth-tab-pill {
  position: absolute; top: 4px; bottom: 4px; width: calc(50% - 4px);
  background: var(--surface-3);
  border: 1px solid var(--line-strong);
  border-radius: 7px;
  transition: left .25s cubic-bezier(.6,.1,.2,1);
}
.auth-forgot {
  font-size: 12px; color: var(--violet-bright);
  text-align: right; margin-top: 4px; cursor: pointer;
}
.auth-err {
  background: rgba(251,113,133,0.08);
  border: 1px solid rgba(251,113,133,0.25);
  color: var(--bad);
  padding: 10px 14px;
  border-radius: 9px;
  font-size: 13px;
}
.auth-divider {
  display: flex; align-items: center; gap: 14px; margin: 4px 0;
}
.auth-divider::before, .auth-divider::after {
  content: ""; flex: 1; height: 1px; background: var(--line);
}
.auth-divider span { font-size: 11px; color: var(--text-4); font-family: var(--mono); letter-spacing: 0.1em; text-transform: uppercase; }

.auth-gift {
  display: flex; align-items: center; justify-content: center; gap: 8px;
  font-size: 12.5px;
  color: var(--text-2);
  padding: 10px;
  background: rgba(168,85,247,0.06);
  border: 1px dashed var(--line-strong);
  border-radius: 10px;
}
.auth-foot { text-align: center; font-size: 13px; color: var(--text-3); margin-top: 4px; }
.auth-foot a { color: var(--violet-bright); cursor: pointer; }

@media (max-width: 880px) {
  .auth-nav { padding: 16px 20px; }
  .auth-grid { grid-template-columns: 1fr; padding: 20px; gap: 32px; }
  .auth-side .h-display { font-size: 40px !important; }
  .auth-card { padding: 24px; }
}
`;

window.Auth = Auth;
