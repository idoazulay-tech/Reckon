/* global React, Ico, Logo, Sidebar */

function Settings({ user, navigate, onSignOut, mobileOpen, onCloseMobile, openMobile }) {
  const [name, setName] = React.useState(user?.name || "Ido Azulay");
  const [email, setEmail] = React.useState(user?.email || "ido@example.com");
  const [resumeFile, setResumeFile] = React.useState({ name: "resume_v3.pdf", size: 248, updated: "May 10, 2026" });
  const [drag, setDrag] = React.useState(false);
  const [showCancel, setShowCancel] = React.useState(false);
  const fileRef = React.useRef(null);

  return (
    <div className="app">
      <Sidebar active="settings" navigate={navigate} user={user} onSignOut={onSignOut} mobileOpen={mobileOpen} onCloseMobile={onCloseMobile} />
      <main className="main">
        <div className="mobile-bar">
          <Logo />
          <button className="menu-btn" onClick={openMobile}><Ico.menu style={{ width: 18, height: 18 }} /></button>
        </div>

        <div className="main-header">
          <div>
            <div className="crumbs">YOUR ACCOUNT</div>
            <h1>Settings.</h1>
          </div>
        </div>

        <div className="settings-grid">
          {/* PROFILE */}
          <section className="set-card">
            <header className="card-h">
              <span className="kicker">Profile</span>
            </header>
            <div className="profile-row">
              <div className="avatar-lg">{name.split(" ").map(s => s[0]).slice(0,2).join("")}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: "var(--serif)", fontSize: 22, color: "var(--text)" }}>{name}</div>
                <div style={{ fontSize: 13, color: "var(--text-3)", fontFamily: "var(--mono)" }}>{email}</div>
              </div>
            </div>
            <div style={{ display: "grid", gap: 14, marginTop: 20 }}>
              <div className="field">
                <label className="field-label">Full name</label>
                <input className="input" value={name} onChange={(e) => setName(e.target.value)} />
              </div>
              <div className="field">
                <label className="field-label">Email address</label>
                <input className="input" value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
              <button className="btn btn-primary" style={{ alignSelf: "flex-start" }}>Save changes</button>
            </div>
          </section>

          {/* PLAN */}
          <section className="set-card">
            <header className="card-h">
              <span className="kicker">Plan & billing</span>
              <span className="pill pill-violet"><span className="dot"></span>Monthly · active</span>
            </header>

            <div className="plan-block">
              <div>
                <div style={{ fontFamily: "var(--serif)", fontSize: 32, color: "var(--text)", letterSpacing: "-0.02em" }}>
                  $19<span style={{ fontSize: 14, color: "var(--text-3)", fontFamily: "var(--mono)", marginLeft: 4 }}>/ month</span>
                </div>
                <div style={{ fontSize: 12, color: "var(--text-3)", marginTop: 4 }}>
                  Next charge · <span style={{ color: "var(--text-2)" }}>June 22, 2026</span>
                </div>
              </div>
              <button className="btn btn-soft btn-sm">Manage billing</button>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 16, marginTop: 18 }}>
              <UsageBar label="Jobs analyzed this month" used={24} cap="∞" pct={60} tone="violet" />
              <UsageBar label="AI emails generated" used={18} cap="∞" pct={45} tone="lilac" />
              <UsageBar label="Daily analyses" used={7} cap={10} pct={70} tone="warn" />
            </div>

            {!showCancel ? (
              <button className="btn-cancel-link" onClick={() => setShowCancel(true)}>
                Cancel subscription
              </button>
            ) : (
              <div className="cancel-confirm">
                <p style={{ fontSize: 13, color: "var(--text-2)", marginBottom: 12, lineHeight: 1.5 }}>
                  Sure? Your data stays read-only for 60 days, then it's deleted.
                </p>
                <div style={{ display: "flex", gap: 8 }}>
                  <button className="btn btn-danger btn-sm">Yes, cancel</button>
                  <button className="btn btn-soft btn-sm" onClick={() => setShowCancel(false)}>Keep my plan</button>
                </div>
              </div>
            )}
          </section>

          {/* RESUME */}
          <section className="set-card resume-card">
            <header className="card-h">
              <span className="kicker">Resume on file</span>
              <span style={{ fontSize: 12, color: "var(--text-3)", fontFamily: "var(--mono)" }}>Used for all AI analyses</span>
            </header>

            <div className="resume-grid">
              <div className="resume-now">
                <div className="resume-file">
                  <div className="resume-ico"><Ico.resume style={{ width: 22, height: 22 }} /></div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 14, color: "var(--text)", fontWeight: 500 }}>{resumeFile.name}</div>
                    <div style={{ fontSize: 11, color: "var(--text-3)", fontFamily: "var(--mono)" }}>
                      {resumeFile.size}KB · Updated {resumeFile.updated}
                    </div>
                  </div>
                  <button className="btn btn-ghost btn-sm">View</button>
                </div>

                <div className="resume-preview">
                  <div style={{ fontFamily: "var(--serif)", fontSize: 18, color: "var(--text)", marginBottom: 4 }}>Ido Azulay</div>
                  <div style={{ fontSize: 11, color: "var(--text-3)", fontFamily: "var(--mono)", marginBottom: 14 }}>Product Designer · Tel Aviv</div>
                  <div style={{ fontSize: 11, color: "var(--violet-bright)", fontFamily: "var(--mono)", letterSpacing: "0.08em", marginBottom: 6 }}>EXPERIENCE</div>
                  <div style={{ fontSize: 12, color: "var(--text-2)", lineHeight: 1.6 }}>
                    Senior Product Designer @ Startup X (2022–2024)<br/>
                    • Led redesign of core product flow, +23% retention<br/>
                    • Conducted 40+ user interviews and usability tests<br/>
                    • Collaborated with engineering across 3 time zones…
                  </div>
                  <div className="preview-fade"></div>
                </div>
              </div>

              <div className="resume-upload">
                <div
                  className={`drop-zone ${drag ? "drag" : ""}`}
                  onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
                  onDragLeave={() => setDrag(false)}
                  onDrop={(e) => { e.preventDefault(); setDrag(false); const f = e.dataTransfer.files[0]; if (f) setResumeFile({ name: f.name, size: Math.round(f.size/1024), updated: "Just now" }); }}
                  onClick={() => fileRef.current?.click()}
                  style={{ padding: "32px 20px" }}
                >
                  <input ref={fileRef} type="file" accept=".pdf,.docx" hidden
                    onChange={(e) => { const f = e.target.files[0]; if (f) setResumeFile({ name: f.name, size: Math.round(f.size/1024), updated: "Just now" }); }}
                  />
                  <div className="drop-ico" style={{ width: 44, height: 44, marginBottom: 12 }}>
                    <Ico.upload style={{ width: 20, height: 20 }} />
                  </div>
                  <div style={{ fontSize: 13, color: "var(--text)", marginBottom: 4 }}>
                    Drop new version or <span style={{ color: "var(--violet-bright)" }}>browse</span>
                  </div>
                  <div style={{ fontSize: 11, color: "var(--text-4)", fontFamily: "var(--mono)" }}>PDF, DOCX · max 5MB</div>
                </div>

                <div className="auth-divider" style={{ margin: "20px 0" }}><span>or paste text</span></div>
                <textarea className="textarea" rows="4" placeholder="Paste your resume text here…"></textarea>
                <button className="btn btn-primary btn-block" style={{ marginTop: 12 }}>Update resume</button>
              </div>
            </div>
          </section>
        </div>

        <style>{settingsStyles}</style>
      </main>
    </div>
  );
}

function UsageBar({ label, used, cap, pct, tone = "violet" }) {
  const colors = {
    violet: "linear-gradient(90deg, #7c3aed, #a855f7)",
    lilac: "linear-gradient(90deg, #a855f7, #d8b4fe)",
    warn: "linear-gradient(90deg, #f59e0b, #fbbf24)",
  };
  return (
    <div className="usage">
      <div className="usage-top">
        <span style={{ fontSize: 13, color: "var(--text-2)" }}>{label}</span>
        <span style={{ fontSize: 12, color: "var(--text-3)", fontFamily: "var(--mono)" }}>
          <strong style={{ color: "var(--text)" }}>{used}</strong> / {cap}
        </span>
      </div>
      <div className="usage-bar">
        <div className="usage-fill" style={{ width: `${pct}%`, background: colors[tone] }}></div>
      </div>
    </div>
  );
}

const settingsStyles = `
.settings-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
}
.settings-grid .resume-card { grid-column: 1 / -1; }
.set-card {
  background: linear-gradient(180deg, var(--surface) 0%, var(--bg-2) 100%);
  border: 1px solid var(--line);
  border-radius: 18px;
  padding: 26px;
  display: flex; flex-direction: column;
}

.profile-row {
  display: flex; align-items: center; gap: 16px;
  padding: 16px;
  background: var(--surface-2);
  border: 1px solid var(--line);
  border-radius: 12px;
}
.avatar-lg {
  width: 56px; height: 56px; border-radius: 50%;
  background: linear-gradient(135deg, var(--violet), var(--violet-deep));
  display: grid; place-items: center;
  font-family: var(--serif); font-style: italic; font-size: 22px; color: white;
  flex-shrink: 0;
  box-shadow: 0 6px 20px -6px var(--violet-glow);
}

.plan-block {
  display: flex; justify-content: space-between; align-items: center;
  padding: 18px;
  background: linear-gradient(135deg, rgba(168,85,247,0.1), transparent);
  border: 1px solid var(--line-strong);
  border-radius: 12px;
}

.usage-top { display: flex; justify-content: space-between; margin-bottom: 8px; }
.usage-bar {
  height: 6px;
  background: var(--surface-2);
  border-radius: 100px;
  overflow: hidden;
  border: 1px solid var(--line);
}
.usage-fill {
  height: 100%;
  border-radius: 100px;
  transition: width .8s cubic-bezier(.6,.1,.2,1);
}

.btn-cancel-link {
  margin-top: 22px;
  align-self: flex-start;
  font-size: 13px;
  color: var(--bad);
  opacity: 0.75;
  font-family: var(--mono);
  letter-spacing: 0.04em;
  border-bottom: 1px dashed rgba(251,113,133,0.4);
  padding-bottom: 1px;
  transition: opacity .15s;
}
.btn-cancel-link:hover { opacity: 1; }
.cancel-confirm {
  margin-top: 22px;
  padding: 16px;
  background: rgba(251,113,133,0.06);
  border: 1px solid rgba(251,113,133,0.2);
  border-radius: 10px;
}

.resume-grid {
  display: grid;
  grid-template-columns: 1.1fr 1fr;
  gap: 20px;
}
.resume-now { display: flex; flex-direction: column; gap: 14px; }
.resume-file {
  display: flex; align-items: center; gap: 14px;
  padding: 14px;
  background: var(--surface-2);
  border: 1px solid var(--line);
  border-radius: 12px;
}
.resume-ico {
  width: 40px; height: 40px;
  border-radius: 10px;
  background: rgba(168,85,247,0.1);
  color: var(--violet-bright);
  display: grid; place-items: center;
  flex-shrink: 0;
}
.resume-preview {
  background: var(--bg);
  border: 1px solid var(--line);
  border-radius: 12px;
  padding: 18px;
  position: relative;
  max-height: 200px;
  overflow: hidden;
}
.preview-fade {
  position: absolute; left: 0; right: 0; bottom: 0; height: 60px;
  background: linear-gradient(transparent, var(--bg));
  pointer-events: none;
}

@media (max-width: 880px) {
  .settings-grid { grid-template-columns: 1fr; }
  .resume-grid { grid-template-columns: 1fr; }
}
`;

window.Settings = Settings;
