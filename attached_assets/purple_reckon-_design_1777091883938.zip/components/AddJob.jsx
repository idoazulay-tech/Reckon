/* global React, Ico */

function AddJobModal({ open, onClose, onCreated }) {
  const [tab, setTab] = React.useState("url");
  const [url, setUrl] = React.useState("");
  const [company, setCompany] = React.useState("");
  const [title, setTitle] = React.useState("");
  const [desc, setDesc] = React.useState("");
  const [file, setFile] = React.useState(null);
  const [drag, setDrag] = React.useState(false);
  const [analyzing, setAnalyzing] = React.useState(false);
  const [stage, setStage] = React.useState(0);
  const fileRef = React.useRef(null);

  React.useEffect(() => {
    if (!open) {
      setTab("url"); setUrl(""); setCompany(""); setTitle(""); setDesc(""); setFile(null);
      setAnalyzing(false); setStage(0);
    }
  }, [open]);

  const stages = ["Reading the posting…", "Cross-referencing your resume…", "Scoring + drafting outreach…"];

  const analyze = () => {
    setAnalyzing(true); setStage(0);
    let i = 0;
    const tick = () => {
      i++;
      if (i < stages.length) { setStage(i); setTimeout(tick, 900); }
      else { setTimeout(() => { onCreated && onCreated(); }, 700); }
    };
    setTimeout(tick, 900);
  };

  const canSubmit = (tab === "url" && url.length > 6) ||
                    (tab === "screenshot" && file) ||
                    (tab === "manual" && company && title);

  if (!open) return null;
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}><Ico.close style={{ width: 16, height: 16 }} /></button>

        {!analyzing ? (
          <>
            <span className="kicker">New application</span>
            <h2 className="h-display" style={{ fontSize: 32, marginTop: 10, marginBottom: 6 }}>
              Add a job, <em>any way you have it.</em>
            </h2>
            <p style={{ color: "var(--text-2)", fontSize: 14, marginBottom: 24 }}>
              Reckon will read it, score it against your resume, and draft outreach in about 30 seconds.
            </p>

            <div className="addjob-tabs">
              {[
                { k: "url", icon: <Ico.link style={{ width: 14, height: 14 }} />, label: "Paste URL" },
                { k: "screenshot", icon: <Ico.image style={{ width: 14, height: 14 }} />, label: "Screenshot" },
                { k: "manual", icon: <Ico.pencil style={{ width: 14, height: 14 }} />, label: "Manual" },
              ].map(t => (
                <button key={t.k} className={tab === t.k ? "active" : ""} onClick={() => setTab(t.k)}>
                  {t.icon}{t.label}
                </button>
              ))}
            </div>

            {tab === "url" && (
              <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
                <div className="field">
                  <label className="field-label">Job posting URL</label>
                  <input className="input" placeholder="https://linkedin.com/jobs/view/…" value={url} onChange={(e) => setUrl(e.target.value)} />
                  <span style={{ fontSize: 12, color: "var(--text-4)", fontFamily: "var(--mono)" }}>
                    Works with LinkedIn, Indeed, Greenhouse, Workday, and any public URL
                  </span>
                </div>
                <div className="extract-box">
                  <span className="kicker">We'll auto-extract</span>
                  <div className="extract-tags">
                    {["Company name", "Job title", "Requirements", "Skills", "Salary range", "Location"].map(t => (
                      <span key={t} className="extract-tag">{t}</span>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {tab === "screenshot" && (
              <div
                className={`drop-zone ${drag ? "drag" : ""} ${file ? "filled" : ""}`}
                onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
                onDragLeave={() => setDrag(false)}
                onDrop={(e) => { e.preventDefault(); setDrag(false); if (e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]); }}
                onClick={() => fileRef.current?.click()}
              >
                <input ref={fileRef} type="file" accept="image/*" hidden onChange={(e) => setFile(e.target.files[0])} />
                {!file ? (
                  <>
                    <div className="drop-ico"><Ico.upload style={{ width: 26, height: 26 }} /></div>
                    <div style={{ fontSize: 16, color: "var(--text)", marginBottom: 6 }}>
                      Drop a screenshot or <span style={{ color: "var(--violet-bright)", textDecoration: "underline" }}>browse</span>
                    </div>
                    <div style={{ fontSize: 12, color: "var(--text-4)", fontFamily: "var(--mono)" }}>
                      PNG, JPG · up to 10MB · vision AI does the rest
                    </div>
                  </>
                ) : (
                  <>
                    <div className="drop-ico" style={{ background: "rgba(110,231,183,0.1)", color: "var(--good)" }}>
                      <Ico.check style={{ width: 26, height: 26 }} />
                    </div>
                    <div style={{ fontSize: 15, color: "var(--text)", marginBottom: 4 }}>{file.name}</div>
                    <div style={{ fontSize: 12, color: "var(--text-4)" }}>{(file.size / 1024).toFixed(0)} KB · ready to analyze</div>
                  </>
                )}
              </div>
            )}

            {tab === "manual" && (
              <div style={{ display: "grid", gap: 16 }}>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                  <div className="field">
                    <label className="field-label">Company</label>
                    <input className="input" placeholder="Stripe" value={company} onChange={(e) => setCompany(e.target.value)} />
                  </div>
                  <div className="field">
                    <label className="field-label">Job title</label>
                    <input className="input" placeholder="Senior Product Designer" value={title} onChange={(e) => setTitle(e.target.value)} />
                  </div>
                </div>
                <div className="field">
                  <label className="field-label">Job description</label>
                  <textarea className="textarea" rows="5" placeholder="Paste the description here…" value={desc} onChange={(e) => setDesc(e.target.value)}></textarea>
                </div>
              </div>
            )}

            <button className="btn btn-primary btn-block btn-lg" disabled={!canSubmit} onClick={analyze} style={{ marginTop: 24, opacity: canSubmit ? 1 : 0.4 }}>
              <Ico.spark style={{ width: 16, height: 16 }} /> Analyze this job
            </button>
            <div style={{ textAlign: "center", fontSize: 11, color: "var(--text-4)", marginTop: 12, fontFamily: "var(--mono)", letterSpacing: "0.06em" }}>
              AI ANALYSIS TAKES 5–15 SECONDS
            </div>
          </>
        ) : (
          <div className="analyzing">
            <div className="analyzing-ring">
              <div className="ring-orb"></div>
              <Ico.spark style={{ width: 28, height: 28, color: "var(--violet-bright)" }} />
            </div>
            <h3 className="h-display" style={{ fontSize: 28, marginBottom: 24 }}>Analyzing<em>…</em></h3>
            <div className="stage-list">
              {stages.map((s, i) => (
                <div key={i} className={`stage ${i < stage ? "done" : i === stage ? "active" : ""}`}>
                  <span className="stage-dot">
                    {i < stage ? <Ico.check style={{ width: 10, height: 10 }} /> : i === stage ? <span className="spinner" style={{ width: 10, height: 10 }}></span> : null}
                  </span>
                  {s}
                </div>
              ))}
            </div>
          </div>
        )}

        <style>{addJobStyles}</style>
      </div>
    </div>
  );
}

const addJobStyles = `
.modal-overlay {
  position: fixed; inset: 0; z-index: 80;
  background: rgba(5, 3, 12, 0.7);
  backdrop-filter: blur(10px);
  display: grid; place-items: center;
  padding: 24px;
  animation: fade .2s ease;
}
@keyframes fade { from { opacity: 0; } }
.modal {
  width: 100%; max-width: 560px;
  background: linear-gradient(180deg, var(--surface) 0%, var(--bg-2) 100%);
  border: 1px solid var(--line-strong);
  border-radius: 22px;
  padding: 32px;
  position: relative;
  box-shadow: 0 40px 100px -20px rgba(0,0,0,0.7), 0 0 60px -20px var(--violet-glow);
  animation: pop .25s cubic-bezier(.6,.1,.2,1);
}
@keyframes pop { from { opacity: 0; transform: translateY(8px) scale(.97); } }
.modal-close {
  position: absolute; top: 16px; right: 16px;
  width: 32px; height: 32px;
  border-radius: 8px;
  display: grid; place-items: center;
  color: var(--text-3);
  transition: background .15s, color .15s;
}
.modal-close:hover { background: var(--surface-2); color: var(--text); }

.addjob-tabs {
  display: grid; grid-template-columns: repeat(3, 1fr);
  background: var(--surface-2);
  border-radius: 10px;
  padding: 4px;
  margin-bottom: 24px;
  gap: 2px;
}
.addjob-tabs button {
  display: flex; align-items: center; justify-content: center; gap: 7px;
  padding: 10px;
  border-radius: 7px;
  font-size: 13px; color: var(--text-3);
  transition: all .15s;
}
.addjob-tabs button.active {
  background: var(--surface-3);
  color: var(--text);
  border: 1px solid var(--line-strong);
  box-shadow: 0 2px 8px rgba(0,0,0,0.2);
}

.extract-box {
  background: rgba(168,85,247,0.05);
  border: 1px dashed var(--line-strong);
  border-radius: 12px;
  padding: 16px;
}
.extract-box .kicker { display: block; margin-bottom: 10px; }
.extract-tags { display: flex; flex-wrap: wrap; gap: 6px; }
.extract-tag {
  font-family: var(--mono);
  font-size: 11px;
  padding: 4px 10px;
  border-radius: 100px;
  background: rgba(168,85,247,0.1);
  color: var(--violet-bright);
}

.drop-zone {
  border: 2px dashed var(--line-strong);
  border-radius: 14px;
  padding: 48px 24px;
  text-align: center;
  cursor: pointer;
  transition: all .2s;
}
.drop-zone:hover, .drop-zone.drag { border-color: var(--violet); background: rgba(168,85,247,0.04); }
.drop-zone.filled { border-style: solid; border-color: rgba(110,231,183,0.4); background: rgba(110,231,183,0.04); }
.drop-ico {
  width: 56px; height: 56px;
  margin: 0 auto 16px;
  border-radius: 14px;
  background: rgba(168,85,247,0.1);
  color: var(--violet-bright);
  display: grid; place-items: center;
}

/* Analyzing */
.analyzing { text-align: center; padding: 24px 0; }
.analyzing-ring {
  width: 100px; height: 100px;
  margin: 0 auto 24px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(168,85,247,0.15), transparent 70%);
  display: grid; place-items: center;
  position: relative;
}
.ring-orb {
  position: absolute; inset: 0;
  border-radius: 50%;
  border: 2px solid transparent;
  border-top-color: var(--violet);
  border-right-color: var(--violet-bright);
  animation: spin 1.6s linear infinite;
}
.h-display em { font-style: italic; color: var(--violet-bright); }
.stage-list { display: flex; flex-direction: column; gap: 10px; max-width: 320px; margin: 0 auto; text-align: left; }
.stage {
  display: flex; align-items: center; gap: 12px;
  padding: 12px 14px;
  border-radius: 10px;
  background: var(--surface-2);
  border: 1px solid var(--line);
  font-size: 13px; color: var(--text-3);
  transition: all .2s;
}
.stage.active { color: var(--text); border-color: var(--line-strong); background: var(--surface-3); }
.stage.done { color: var(--text-2); }
.stage-dot {
  width: 18px; height: 18px;
  border-radius: 50%;
  border: 1px solid var(--line);
  display: grid; place-items: center;
  flex-shrink: 0;
  color: var(--good);
}
.stage.done .stage-dot { background: var(--good); border-color: var(--good); color: var(--bg); }
.stage.active .stage-dot { border-color: var(--violet); }
`;

window.AddJobModal = AddJobModal;
