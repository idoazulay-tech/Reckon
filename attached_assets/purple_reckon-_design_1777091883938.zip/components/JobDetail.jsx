/* global React, Ico, Logo, ScoreRing, Sidebar */

function JobDetail({ user, navigate, onSignOut, mobileOpen, onCloseMobile, openMobile, isPro }) {
  const [copied, setCopied] = React.useState(false);
  const [regenLeft, setRegenLeft] = React.useState(2);
  const [regening, setRegening] = React.useState(false);
  const [status, setStatus] = React.useState("Applied");

  const copyEmail = () => { setCopied(true); setTimeout(() => setCopied(false), 1800); };
  const regen = () => {
    if (regenLeft <= 0) return;
    setRegening(true);
    setTimeout(() => { setRegenLeft(n => n - 1); setRegening(false); }, 1200);
  };

  return (
    <div className="app">
      <Sidebar active="all-jobs" navigate={navigate} user={user} onSignOut={onSignOut} mobileOpen={mobileOpen} onCloseMobile={onCloseMobile} />
      <main className="main">
        <div className="mobile-bar">
          <Logo />
          <button className="menu-btn" onClick={openMobile}><Ico.menu style={{ width: 18, height: 18 }} /></button>
        </div>

        <a className="back-link" onClick={() => navigate("dashboard")}><Ico.arrowLeft style={{ width: 14, height: 14 }} /> Back to pipeline</a>

        <div className="detail-head">
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
              <div className="job-logo-lg">G</div>
              <div>
                <div style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--text-3)", letterSpacing: "0.04em" }}>
                  Google · Mountain View, CA · Remote-friendly
                </div>
                <h1 className="h-display" style={{ fontSize: 36, marginTop: 4 }}>Senior <em>UX Researcher.</em></h1>
              </div>
            </div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 12 }}>
              <span className="meta-chip">Full-time</span>
              <span className="meta-chip">$140k–$190k</span>
              <span className="meta-chip">Applied 3 days ago</span>
              <span className="meta-chip">5+ yrs</span>
            </div>
          </div>
          <select className="select status-select" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option>Saved</option>
            <option>Applied</option>
            <option>Interview</option>
            <option>Offer</option>
            <option>Rejected</option>
          </select>
        </div>

        <div className="detail-grid">
          {/* LEFT */}
          <div className="detail-left">
            <section className="detail-card">
              <header className="card-h">
                <span className="kicker">Skills gap</span>
                <span className="pill pill-bad">4 missing</span>
              </header>
              <p className="card-lead">Add or reframe these to lift your match score by an estimated <strong style={{ color: "var(--violet-bright)" }}>+18 points</strong>.</p>
              <div className="gap-list">
                {[
                  { tag: "SQL proficiency", level: "critical", note: "Mentioned 3× in the JD. Even self-taught counts." },
                  { tag: "Quantitative methods", level: "critical", note: "Reframe survey work as 'mixed-methods research'." },
                  { tag: "5+ yrs experience", level: "important", note: "Lead with total years across roles in your headline." },
                  { tag: "Cross-functional leadership", level: "nice", note: "Add one bullet about influencing without authority." },
                ].map((g, i) => (
                  <div className="gap-row" key={i}>
                    <div className="gap-row-l">
                      <span className={`gap-dot gap-${g.level}`}></span>
                      <div>
                        <div className="gap-tag">{g.tag}</div>
                        <div className="gap-note">{g.note}</div>
                      </div>
                    </div>
                    <span className={`gap-pill gap-${g.level}`}>{g.level}</span>
                  </div>
                ))}
              </div>
            </section>

            <section className="detail-card">
              <header className="card-h">
                <span className="kicker">Resume rewrite tips</span>
              </header>
              <ol className="rewrite-list">
                <li>Add a bullet about any data analysis or SQL work, even if from a personal project. Quantify it.</li>
                <li>Reframe "user testing" as "mixed-methods research" — exact language Google uses internally.</li>
                <li>Mention any cross-team collaboration where you influenced product decisions without direct authority.</li>
                <li>Include a concrete metric for each case study (e.g. "reduced task completion time by 34%").</li>
              </ol>
            </section>

            <section className="detail-card">
              <header className="card-h">
                <span className="kicker">Job description</span>
              </header>
              <div className="jd-body">
                <p>Google's UX Research team is looking for a senior researcher to lead end-to-end studies that shape product strategy across Search and Assistant.</p>
                <ul>
                  <li>5+ years of UX research in a fast-paced product environment</li>
                  <li>Proficiency in quantitative research methods and SQL</li>
                  <li>Experience with large-scale longitudinal studies</li>
                  <li>Strong synthesis of mixed-methods findings into actionable insights</li>
                  <li>BA/BS in HCI, Psychology, or related field; advanced degree a plus</li>
                </ul>
              </div>
            </section>
          </div>

          {/* RIGHT */}
          <div className="detail-right">
            <section className="detail-card score-card">
              <header className="card-h">
                <span className="kicker">Match score</span>
                <span className="pill pill-violet">Good fit</span>
              </header>
              <div style={{ display: "grid", placeItems: "center", padding: "8px 0 16px" }}>
                <ScoreRing value={72} size={160} stroke={11} />
              </div>
              <div className="score-grid">
                <div><div className="score-num good">8/12</div><div className="score-lbl">skills matched</div></div>
                <div><div className="score-num bad">4</div><div className="score-lbl">gaps found</div></div>
                <div><div className="score-num">71%</div><div className="score-lbl">ATS pass-through</div></div>
                <div><div className="score-num good">A−</div><div className="score-lbl">market fit</div></div>
              </div>
            </section>

            <section className="detail-card">
              <header className="card-h">
                <span className="kicker">Outreach email</span>
                <button className={`btn btn-soft btn-sm ${regening ? "disabled" : ""}`} onClick={regen} disabled={regenLeft <= 0 || regening}>
                  {regening ? <span className="spinner"></span> : <Ico.refresh style={{ width: 12, height: 12 }} />}
                  Regenerate · {regenLeft}
                </button>
              </header>
              <div className={`email-box ${!isPro ? "blurred" : ""}`}>
                <div className="email-meta">
                  <div><span>Subject</span> Senior UX Researcher — quick intro</div>
                  <div><span>To</span> hiring@google.com</div>
                </div>
                <div className="email-body">
                  <p>Hi Mira,</p>
                  <p>Saw your team's open Senior UX Researcher role on Search. The thing that pulled me in was the line about "translating mixed-methods findings into product strategy" — that's been the exact center of my last four years.</p>
                  <p>At my current role I led an end-to-end research program for our onboarding flow, combining diary studies with a 1,200-participant survey. The redesign that came out of it cut first-week churn by 34%. The thing I'm proudest of isn't the number — it's that engineering picked up the recommendations without a single follow-up meeting.</p>
                  <p>I'd love fifteen minutes to hear what the team's working on next. Resume attached, but happy to start with a conversation.</p>
                  <p>— Ido</p>
                </div>
                {!isPro && (
                  <div className="blur-overlay">
                    <div className="lock-card">
                      <Ico.lock style={{ width: 22, height: 22, color: "var(--violet-bright)" }} />
                      <div style={{ fontFamily: "var(--serif)", fontSize: 22, color: "var(--text)", letterSpacing: "-0.01em" }}>
                        See the full email
                      </div>
                      <p style={{ fontSize: 13, color: "var(--text-2)", maxWidth: 240, lineHeight: 1.5 }}>
                        Free tier shows the opener. Upgrade to unlock the full draft + unlimited regenerations.
                      </p>
                      <button className="btn btn-primary btn-sm">Upgrade to unlock</button>
                    </div>
                  </div>
                )}
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginTop: 14 }}>
                <button className="btn btn-soft" onClick={copyEmail}>
                  <Ico.copy style={{ width: 14, height: 14 }} />{copied ? "Copied!" : "Copy email"}
                </button>
                <button className="btn btn-primary">Send via Gmail <Ico.arrow style={{ width: 14, height: 14 }} /></button>
              </div>
            </section>
          </div>
        </div>

        <style>{detailStyles}</style>
      </main>
    </div>
  );
}

const detailStyles = `
.back-link {
  display: inline-flex; align-items: center; gap: 8px;
  font-family: var(--mono); font-size: 12px; letter-spacing: 0.06em;
  color: var(--text-3); text-transform: uppercase;
  cursor: pointer; margin-bottom: 22px;
  transition: color .15s;
}
.back-link:hover { color: var(--violet-bright); }

.detail-head {
  display: flex; justify-content: space-between; align-items: flex-start;
  margin-bottom: 36px;
  gap: 16px;
}
.job-logo-lg {
  width: 56px; height: 56px;
  border-radius: 14px;
  background: linear-gradient(135deg, var(--surface-2), var(--surface-3));
  border: 1px solid var(--line-strong);
  display: grid; place-items: center;
  font-family: var(--serif); font-style: italic; font-size: 28px;
  color: var(--violet-bright);
  flex-shrink: 0;
}
.meta-chip {
  font-family: var(--mono); font-size: 11px;
  padding: 4px 10px; border-radius: 6px;
  background: var(--surface); border: 1px solid var(--line);
  color: var(--text-2);
}
.status-select {
  width: 160px; height: 40px;
  font-size: 13px;
  cursor: pointer;
}

.detail-grid {
  display: grid;
  grid-template-columns: 1fr 400px;
  gap: 20px;
}
.detail-left, .detail-right { display: flex; flex-direction: column; gap: 20px; }

.detail-card {
  background: linear-gradient(180deg, var(--surface) 0%, var(--bg-2) 100%);
  border: 1px solid var(--line);
  border-radius: 16px;
  padding: 24px;
}
.card-h { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.card-lead { font-size: 14px; color: var(--text-2); margin-bottom: 18px; line-height: 1.55; }

.gap-list { display: flex; flex-direction: column; gap: 8px; }
.gap-row {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px;
  border-radius: 10px;
  background: var(--surface-2);
  border: 1px solid var(--line);
  gap: 12px;
}
.gap-row-l { display: flex; align-items: center; gap: 12px; flex: 1; min-width: 0; }
.gap-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
.gap-dot.gap-critical { background: var(--bad); box-shadow: 0 0 8px var(--bad); }
.gap-dot.gap-important { background: var(--warn); box-shadow: 0 0 8px var(--warn); }
.gap-dot.gap-nice { background: var(--violet-bright); }
.gap-tag { font-size: 14px; font-weight: 500; color: var(--text); margin-bottom: 2px; }
.gap-note { font-size: 12px; color: var(--text-3); line-height: 1.45; }
.gap-pill {
  font-family: var(--mono); font-size: 10px; letter-spacing: 0.08em;
  text-transform: uppercase;
  padding: 3px 8px; border-radius: 100px; flex-shrink: 0;
}
.gap-pill.gap-critical { color: var(--bad); background: rgba(251,113,133,0.08); }
.gap-pill.gap-important { color: var(--warn); background: rgba(251,191,36,0.08); }
.gap-pill.gap-nice { color: var(--violet-bright); background: rgba(168,85,247,0.08); }

.rewrite-list {
  list-style: none; counter-reset: r;
  display: flex; flex-direction: column; gap: 14px;
}
.rewrite-list li {
  position: relative;
  padding-left: 36px;
  font-size: 14px; color: var(--text-2); line-height: 1.55;
  counter-increment: r;
}
.rewrite-list li::before {
  content: counter(r, decimal-leading-zero);
  position: absolute; left: 0; top: 0;
  font-family: var(--mono); font-size: 12px;
  color: var(--violet-bright);
  background: rgba(168,85,247,0.1);
  border: 1px solid var(--line-strong);
  width: 26px; height: 26px;
  border-radius: 50%;
  display: grid; place-items: center;
}

.jd-body { font-size: 14px; color: var(--text-2); line-height: 1.7; }
.jd-body p { margin-bottom: 12px; }
.jd-body ul { padding-left: 18px; }
.jd-body li { margin-bottom: 6px; }

.score-grid {
  display: grid; grid-template-columns: 1fr 1fr;
  gap: 8px;
}
.score-grid > div {
  background: var(--surface-2);
  border: 1px solid var(--line);
  border-radius: 10px;
  padding: 12px;
  text-align: center;
}
.score-num {
  font-family: var(--serif); font-size: 26px; font-weight: 400;
  letter-spacing: -0.02em; line-height: 1;
  color: var(--text);
}
.score-num.good { color: var(--good); }
.score-num.bad { color: var(--bad); }
.score-lbl { font-size: 11px; color: var(--text-3); margin-top: 4px; font-family: var(--mono); }

.email-box {
  background: var(--surface-2);
  border: 1px solid var(--line);
  border-radius: 12px;
  padding: 18px;
  position: relative;
  font-size: 13px;
  max-height: 360px; overflow: hidden;
}
.email-meta {
  font-family: var(--mono); font-size: 11px;
  color: var(--text-3);
  padding-bottom: 12px;
  margin-bottom: 14px;
  border-bottom: 1px dashed var(--line);
}
.email-meta span { color: var(--text-4); margin-right: 8px; }
.email-meta div { margin-bottom: 4px; }
.email-body p { color: var(--text); line-height: 1.65; margin-bottom: 12px; font-size: 13.5px; }
.blur-overlay {
  position: absolute; left: 0; right: 0; bottom: 0; top: 50%;
  background: linear-gradient(180deg, transparent, rgba(15,10,26,0.95) 40%);
  display: flex; align-items: flex-end; justify-content: center;
  padding: 24px;
  backdrop-filter: blur(2px);
}
.lock-card {
  text-align: center;
  display: flex; flex-direction: column; align-items: center; gap: 10px;
}

@media (max-width: 1100px) { .detail-grid { grid-template-columns: 1fr; } }
@media (max-width: 880px) {
  .detail-head { flex-direction: column; }
  .status-select { width: 100%; }
}
`;

window.JobDetail = JobDetail;
