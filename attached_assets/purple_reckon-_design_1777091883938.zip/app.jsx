/* global React, ReactDOM, Landing, Auth, Dashboard, AddJobModal, JobDetail, Settings, useAuth, Toast, Field */
const { useState: useStateApp, useEffect: useEffectApp, useCallback: useCallbackApp } = React;

function App() {
  const { user, login, logout } = useAuth();

  // Routing via URL hash
  const parseHash = () => {
    const h = window.location.hash.replace(/^#\/?/, "") || "landing";
    const [route, ...rest] = h.split("/");
    return { route: route || "landing", params: rest.join("/") };
  };
  const [{ route, params }, setRoute] = useStateApp(parseHash);
  const [addJobOpen, setAddJobOpen] = useStateApp(false);
  const [toast, setToast] = useStateApp("");
  const [mobileNav, setMobileNav] = useStateApp(false);
  const [isPro, setIsPro] = useStateApp(false);

  useEffectApp(() => {
    const h = () => setRoute(parseHash());
    window.addEventListener("hashchange", h);
    return () => window.removeEventListener("hashchange", h);
  }, []);

  const navigate = useCallbackApp((to, opts = {}) => {
    let target = to;
    if (opts.jobId) target = `${to}/${opts.jobId}`;
    window.location.hash = `#/${target}`;
  }, []);

  // Protected routes
  const protectedRoutes = ["dashboard", "all-jobs", "resume", "reminders", "analytics", "settings", "job-detail"];
  useEffectApp(() => {
    if (protectedRoutes.includes(route) && !user) navigate("login");
    if ((route === "login" || route === "signup") && user) navigate("dashboard");
  }, [route, user]);

  const handleSignOut = () => { logout(); navigate("landing"); };

  let screen;
  if (route === "landing") screen = <Landing navigate={navigate} />;
  else if (route === "login" || route === "signup") screen = <Auth mode={route} navigate={navigate} onLogin={login} />;
  else if (!user) screen = <div style={{ padding: 60, textAlign: "center", color: "var(--text-3)" }}>Redirecting…</div>;
  else if (route === "job-detail") screen = (
    <JobDetail user={user} navigate={navigate} onSignOut={handleSignOut} mobileOpen={mobileNav} openMobile={() => setMobileNav(true)} onCloseMobile={() => setMobileNav(false)} isPro={isPro} />
  );
  else if (route === "settings") screen = (
    <Settings user={user} navigate={navigate} onSignOut={handleSignOut} mobileOpen={mobileNav} openMobile={() => setMobileNav(true)} onCloseMobile={() => setMobileNav(false)} />
  );
  else screen = (
    <Dashboard user={user} navigate={navigate} onAddJob={() => setAddJobOpen(true)} onSignOut={handleSignOut}
      mobileOpen={mobileNav} openMobile={() => setMobileNav(true)} onCloseMobile={() => setMobileNav(false)} />
  );

  return (
    <>
      {screen}
      <AddJobModal open={addJobOpen} onClose={() => setAddJobOpen(false)} onCreated={() => { setAddJobOpen(false); setToast("Job analyzed and added"); navigate("job-detail", { jobId: 4 }); }} />
      <Toast message={toast} onDone={() => setToast("")} />

      {/* Pro toggle for demo */}
      <div className="demo-toggle" title="Toggle Pro tier (demo)">
        <button onClick={() => setIsPro(p => !p)}>
          <span className={`dot ${isPro ? "on" : ""}`}></span>
          {isPro ? "Pro" : "Free"} tier
        </button>
      </div>

      <style>{`
        .demo-toggle {
          position: fixed; bottom: 20px; right: 20px; z-index: 70;
          opacity: 0.6; transition: opacity .2s;
        }
        .demo-toggle:hover { opacity: 1; }
        .demo-toggle button {
          display: flex; align-items: center; gap: 8px;
          background: var(--surface-2); border: 1px solid var(--line-strong);
          color: var(--text-2); padding: 8px 14px; border-radius: 100px;
          font-size: 11px; font-family: var(--mono); letter-spacing: 0.06em; text-transform: uppercase;
        }
        .demo-toggle .dot { width: 7px; height: 7px; border-radius: 50%; background: var(--text-4); }
        .demo-toggle .dot.on { background: var(--violet-bright); box-shadow: 0 0 10px var(--violet-bright); }
      `}</style>
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
